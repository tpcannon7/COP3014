/* 
Name: Trevor Cannon
Date: 2-6-2024
Assignment: Homework #3
Due Date: 2-15-2024
About this project: Plays a coin game with the user where the user sets
a target amount and tries to reach that amount using different US coins
Assumptions: Assumes the user does not enter different data type for entries when prompted

All work below was performed by Trevor Cannon 

*/


#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    //variable declarations
    int numWins = 0, numLosses = 0;
    
    //user entry number of coins
    int numHalf, numQuart, numDimes, numNickels, numPennies;
    
    //values of coins
    const double HALF = 0.5;
    const double QUART = 0.25;
    const double DIMES = 0.10;
    const double NICKELS = 0.05;
    const double PENNIES = 0.01;
    
    
    double total;
    
    double targetAmount;
    
    char choice;
    
    
    cout << "Welcome to the Coin Game! Make a selection:" <<endl;
    
    //general loop for game, exits if entering 'q' or 'Q'
    do
    {
        //gives user the "menu" to select choice (plau, stats, quit)
        cout <<endl << "p - play" <<endl <<"s - stats" <<endl <<"q - quit";
        cout << endl << "choice: ";
        cin >> choice;
        cout <<endl;
        
        //if statement for "play" choice
        if (choice == 'P' || choice == 'p')
        {
            cout << "Enter target amount $dd.cc: ";
            cin >> targetAmount;
            
            //loop for if target amount entered by user is negative
            while (targetAmount < 0)
            {
                cout << "Cannot be negative. Try again. ";
                cin >> targetAmount;
            }
            //prompts users to enter their number of coins
            if (targetAmount > 0)
            {
                cout << "Okay! You need to match the value of $" <<showpoint <<setprecision(2) <<fixed <<targetAmount <<endl;
                cout << "Enter the number of:" <<endl;
                cout << "Half Dollars: ";
                cin >> numHalf;
                cout << "Quarters: ";
                cin >> numQuart;
                cout << "Dimes: ";
                cin >> numDimes;
                cout << "Nickels: ";
                cin >> numNickels;
                cout << "Pennies: ";
                cin >> numPennies;
                
                //calculates total value of coins that user entered 
                total = ((numHalf*HALF)+(numQuart*QUART)+(numDimes*DIMES)+(numNickels*NICKELS)+(numPennies*PENNIES));
                
                //calculates if user win
                if (total-targetAmount == 0)
                {
                    cout << "\nYOU WIN!";
                    numWins++;
                }
                //error checking for if user enters negative coins
                else if (numHalf < 0 || numQuart < 0 || numDimes < 0 || numNickels < 0 || numPennies < 0)
                {
                    cout << "\nYou cannot enter a negative number of coins. You lose. ";
                    numLosses++;
                }
                //calculates if user loss
                else if (total-targetAmount !=0)
                {
                    cout << "\nYou LOST by: $" <<setprecision(2) <<fixed <<abs(total-targetAmount);
                    numLosses++;
                }
                
            }
            
            
        }
    
        //stats choice
        else if (choice == 's' || choice == 'S')
        {
            cout << "Stats: " <<endl <<"Wins: "<<numWins <<endl << "Losses: " <<numLosses <<endl;
        }
        //if user has played atleast one game and decides to quit
        else if (numWins+numLosses > 0 && choice == 'q' || choice == 'Q')
        {
            cout << "Final Stats: " <<endl << "Wins: " <<numWins <<endl << "Losses: " <<numLosses <<endl;
            cout << "Final Win Percentage: "  <<fixed <<(static_cast<double>(numWins)/(numWins+numLosses)*100) << "%";
        }
        //if user quits before playing a game
        else if (numWins+numLosses == 0 && choice == 'q' || choice == 'Q')
        {
            cout << "Final Stats: " <<endl << "Wins: " <<numWins <<endl << "Losses: " <<numLosses <<endl;
            cout << "Final Win Percentage: 0.00%";
            cout << "\nGuess you're scared! Come back when you're ready to play!";
        }
        //if user enters a character not 's', 'p', or 'q'
        else
        {
            cout << "Invalid option. " <<endl;
        }
        
        cout <<endl;
        
    }while(choice != 'q' && choice != 'Q');
    
    
     return 0;
}









