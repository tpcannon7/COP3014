/* Name: Trevor Cannon
Date: 2-22-2024
Assignment: Homework #4
Due Date: 2-26-2024
About this project: Calculates NFL passer rating using the same formula used in the NFL by taking in
two quarterbacks stats. Also compares the two quarterbacks's stats.
Assumptions: Assumes correct input for quarterback stats and that atleast one pair of quarterbacks
will be analyzed.

All work below was performed by Trevor Cannon */

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

void welcomeMessage();
double getPasserRating(double,double,double,double,double);

int main()
{
    char choice;
    int att, comp, passyds, td, intercept;
    int numPair = 0;
    //displays welcome message funtion to user
    welcomeMessage();
    double passRateA, passRateB;
    
    //main loop that asks user to input quarterback stats
    do
    {
        //user input for quarterback A
        cout << "Enter single game information for Player A: " <<endl;
        cout << "Attempts: ";
        cin >> att;
        cout << "Completions: ";
        cin >> comp;
        cout << "Passing Yards: ";
        cin >> passyds;
        cout << "Touchdowns: ";
        cin >> td;
        cout << "Interceptions: ";
        cin >> intercept;
        
        cout << fixed << setprecision(1);
        //calls passer rating function calculate quarterback A stats
        passRateA = getPasserRating(att,comp,passyds,td,intercept);
        
        //user input for quarterback B
        cout << "\nEnter single game information for Player B: " <<endl;
        cout << "Attempts: ";
        cin >> att;
        cout << "Completions: ";
        cin >> comp;
        cout << "Passing Yards: ";
        cin >> passyds;
        cout << "Touchdowns: ";
        cin >> td;
        cout << "Interceptions: ";
        cin >> intercept;
        
        //calls passer rating function calculate quarterback B stats
        passRateB = getPasserRating(att,comp,passyds,td,intercept);
        
        cout << "\nPlayer A's single game passer rating: " <<passRateA <<endl;
        cout << "Player B's single game passer rating: " <<passRateB <<endl;
        
        if (passRateA > passRateB)
        {
            cout << "Player A was better than Player B by a difference of " <<abs(passRateA-passRateB) <<endl;
        }
        else if (passRateB > passRateA)
        {
            cout << "Player B was better than Player A by a difference of " <<abs(passRateA-passRateB) <<endl;
        }
        else if (passRateA == passRateB)
        {
            cout << "Player A and B have the same rating!" <<endl;
        }
        
        if (passRateA >= 158.3)
        {
            cout << "\nPlayer A had a PERFECT passer rating.";
        }
        if (passRateB >= 158.3)
        {
            cout << "\nPlayer B had a PERFECT passer rating.";
        }
        
        
        cout << "\n\nWould you like to compare another pair of players? (Y or N): ";
        cin >> choice;
        cout <<endl;
        
        numPair++;
        
    }while(choice == 'Y' || choice == 'y');

    if(choice == 'N' || choice == 'n')
        if(numPair == 1)
            cout << "You compared " <<numPair << " pair of players. ";
        else if (numPair > 1)
            cout << "You compared " <<numPair << " pairs of players.";
    else
        cout << "Invalid entry. Exiting program...";

    return 0;
}

//passer rating function that calculates passer rating based on stats
double getPasserRating(double att,double comp,double passyds,double td,double intercept)
{
    double a, b, c, d;
    
    if (att <= 0)
        return 0.0;
    
    else if (att > 0)
    {
        a = ((comp/att) - 0.3) * 5;
        if (a > 2.375)
            a = 2.375;
        else if (a < 0)
            a = 0;
        
        b =  ((passyds/att) - 3)*0.25;
    
        if (b > 2.375)
            b = 2.375;
        else if (b < 0)
            b = 0;
        
        c = (td/att)*20;
    
        if (c > 2.375)
            c = 2.375;
        else if (c < 0)
            c = 0;
        
        d = 2.375 - ((intercept/att)*25);
    
        if (d > 2.375)
            d = 2.375;
        else if (d < 0)
            d = 0;
    }
    return ((a+b+c+d)/6)*100;
}

//welcome message function displayed at beginning of program
void welcomeMessage()
{
    cout << "Welcome to the NFL Quarterback Passer Rating Calculator!" <<endl;
    cout << "A perfect passer rating (158.3) requires at least:" <<endl;
    cout << "77.5% completion percentage" <<endl;
    cout << "12.5 yards per attempt" <<endl;
    cout << "11.875% touchdown % per attempt" <<endl;
    cout << "No interceptions" <<endl <<endl;
}











