/* 

Name: Trevor Cannon
Date: 1-31-2024
Assignment: Homework #2
Due Date: 2-5-2024
About this project: Calculates grade for the class COP3014
Assumptions: Assumes correct user input, but error checks for proper integer values when entering points and checks extra credit (y/n) was entered correctly

All work below was performed by Trevor Cannon 

*/

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    
    const int ASSIGNPTSPOSS = 700;
    const int MIDTERMPTSPOSS= 100;  
    const int REVELPTSPOSS = 500; 
    const int FINALPTSPOSS = 100;

    double assignptsearn, midtermptsearn, revelptsearn, finalptsearn, extraptsearn;
    
    double A, B, C, D;
    
    double finalavg;
    
    char yesno;

    cout << "Assignment Points: ";
    cin >> assignptsearn;
    cout << "Midterm Exam: ";
    cin >> midtermptsearn;
    cout << "Revel Points: ";
    cin >> revelptsearn;
    cout << "Final Exam: ";
    cin >> finalptsearn;
    
    if (assignptsearn >= 0 && midtermptsearn >= 0 && revelptsearn >= 0 && finalptsearn >= 0)
    {
        A = ((revelptsearn/REVELPTSPOSS) * .1);
        B = (((assignptsearn)/ASSIGNPTSPOSS) * .4); 
        C = ((midtermptsearn/MIDTERMPTSPOSS) * .2);
        D = ((finalptsearn/FINALPTSPOSS) * .3);
        
        finalavg = (A + B + C + D)*100;
    
        cout << "Did you earn extra credit? (y/n): ";
        cin >> yesno;
    
        if (yesno == 'Y' || yesno == 'y')
        {
            cout << "Extra Credit Points Earned: ";
            cin >> extraptsearn;
        
            A = ((revelptsearn/REVELPTSPOSS) * .1);
            B = (((assignptsearn+extraptsearn)/ASSIGNPTSPOSS) * .4); 
            C = ((midtermptsearn/MIDTERMPTSPOSS) * .2);
            D = ((finalptsearn/FINALPTSPOSS) * .3);
        
            finalavg = (A + B + C + D)*100;
        
            cout << "\nFinal Course Average: " <<setprecision(3) <<finalavg <<"%\n";
        
            if (finalavg >= 92.00)
            {
                cout << "Final Course Grade: A ";
            }
            else if (finalavg <= 91.99 && finalavg >= 90.00)
            {
                cout << "Final Course Grade: A- ";
            }
            else if (finalavg <= 89.99 && finalavg >= 88.00)
            {
                cout << "Final Course Grade: B+ ";
            }
            else if (finalavg <= 87.99 && finalavg >= 82.00)
            {
                cout << "Final Course Grade: B ";
            }
            else if (finalavg <= 81.99 && finalavg >= 80.00)
            {
                cout << "Final Course Grade: B- ";
            }
            else if (finalavg <= 79.99 && finalavg >= 78.00)
            {
                cout << "Final Course Grade: C+ ";
            }
            else if (finalavg <= 77.99 && finalavg >= 72.00)
            {
                cout << "Final Course Grade: C ";
            }
            else if (finalavg <= 71.99 && finalavg >= 69.00)
            {
                cout << "Final Course Grade: C- ";
            }
            else if (finalavg <= 68.99 && finalavg >= 60.00)
            {
                cout << "Final Course Grade: D ";
            }
            else if (finalavg <= 59.99 && finalavg >= 0.00)
            {
                cout << "Final Course Grade: F ";
            }
        }
        else if (yesno == 'N' || yesno == 'n')
        {
         cout << "\nFinal Course Average: " <<setprecision(3) <<finalavg <<"%\n";
        
            if (finalavg >= 92.00)
            {
                cout << "Final Course Grade: A ";
            }
            else if (finalavg <= 91.99 && finalavg >= 90.00)
            {
                cout << "Final Course Grade: A- ";
            }
            else if (finalavg <= 89.99 && finalavg >= 88.00)
            {
                cout << "Final Course Grade: B+ ";
            }
            else if (finalavg <= 87.99 && finalavg >= 82.00)
            {
                cout << "Final Course Grade: B ";
            }
            else if (finalavg <= 81.99 && finalavg >= 80.00)
            {
                cout << "Final Course Grade: B- ";
            }
            else if (finalavg <= 79.99 && finalavg >= 78.00)
            {
                cout << "Final Course Grade: C+ ";
            }
            else if (finalavg <= 77.99 && finalavg >= 72.00)
            {
                cout << "Final Course Grade: C ";
            }
            else if (finalavg <= 71.99 && finalavg >= 69.00)
            {
                cout << "Final Course Grade: C- ";
            }
            else if (finalavg <= 68.99 && finalavg >= 60.00)
            {
                cout << "Final Course Grade: D ";
            }
            else if (finalavg <= 59.99 && finalavg >= 0.00)
            {
                cout << "Final Course Grade: F ";
            }
        }
        else
        {
            cout << "\nInvalid option, exiting program.";
        }
    }
    else if (assignptsearn <= 0 || midtermptsearn <= 0 || revelptsearn <= 0 || finalptsearn <= 0)
    {
        cout << "\nInvalid grade entry, exiting program.";
    }
    return 0;
}




