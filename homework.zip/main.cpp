/*
Name: Trevor Cannon
Date: January 23, 2024
Course: COP3014
Assignment: Homework #1: Hogwarts Express Trolley Menu
Purpose: Calculate price (with tax) of different items that could be bought from the Hogwarts Express Trolley
Assumptions: Assumes correct user input when prompted for menu quantities (no characters or decimals)
All work below was done by Trevor Cannon
*/


#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    //declaring + initializing constant variables for price of items and wizard tax
    const double bbeans = 4.00, cfrog = 1.50, ebons = 2.50, ccakes = 6.25;
    const double wiztax = 0.065;
    
    //variables for number of each item bought
    int numbbeans, numcfrogs, numebons, numccakes;
    
    //declaring the variable used to find the total cost before and after tax
    double beforetotal;
    
    cout << fixed << showpoint << setprecision(2);
    
    //trolley menu + prices
    cout << "Anything off of the trolley, dears?" <<endl <<endl;
    cout << "\tTROLLEY MENU" <<endl;
    cout << "\t----------------------" <<endl;
    cout << "\tBertie Bott's Every Flavor Beans: $" <<bbeans <<endl;
    cout << "\tChocolate Frog: $" <<cfrog <<endl;
    cout << "\tExploding Bonbons: $" <<ebons <<endl;
    cout << "\tCauldron Cakes: $" <<ccakes <<endl;
    cout << "\t----------------------" <<endl <<endl;
    
    //user input of how much of each item they want
    cout << "How many Bertie Bott's Every Flavor Beans? --> ";
    cin >> numbbeans;
    cout << "How many Chocolate Frogs? --> ";
    cin >> numcfrogs;
    cout << "How many Exploding Bonbons? --> ";
    cin >> numebons;
    cout << "How many Cauldron Cakes? --> ";
    cin >> numccakes;
    
    //initializing variable of the formula for calculating total cost of all items
    beforetotal = (numbbeans*bbeans + numcfrogs*cfrog + numebons*ebons + numccakes*ccakes);
    
    //description of total before tax, how much tax is applied, and the total with tax
    cout << "\nTotal (Before Wizard Tax) : $" <<beforetotal <<endl;
    cout << "Tax (6.50%) : $" <<beforetotal*wiztax <<endl;
    cout << "Total (After Wizard Tax) : $" <<beforetotal*wiztax + beforetotal <<endl <<endl;
    
    cout << "Enjoy your candies!";
    
    return 0;
}



